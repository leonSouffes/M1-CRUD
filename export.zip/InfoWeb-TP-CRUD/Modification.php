<?php
include_once("Utilities.php");
include_once("Backend/EpisodeMetier.php");
include_once("Backend/PersonneMetier.php");
include_once("Backend/SaisonMetier.php");
include_once("Backend/SerieMetier.php");

echo getHeader("Modification");
?>

    <div class="container-fluid">
        <div class="row">
            <?php
            echo getSideBar();
            ?>

            <?php
            echo "<div class=\"col-10 mt-2\">";

            if (isset($_GET["type"])) {
                if (isset($_GET["id"]) && isset($_GET["modifier"])) {
                    // on va modifier cet id !!!
                    if ($_GET["type"] == "personne") {
                        $metier = new PersonneMetier();
                        PersonneMetier::initPDO();
                        $truc = PersonneMetier::getAll();
                        $metier = new PersonneMetier();

                        $metier->setId    ($_GET['id']);
                        $metier->setNom   ($_GET['nom']);
                        $metier->setPrenom($_GET['prenom']);

                        $metier->save();

                    } else if ($_GET["type"] == "episode") {
                        EpisodeMetier::initPDO();
                        $trucs = EpisodeMetier::getAll();
                        $metier = new EpisodeMetier();

                        $metier->setIdEpisode($_GET['id']);
                        $metier->setIdSaison($_GET['idSaison']);
                        $metier->setIdSerie($_GET['idSerie']);
                        $metier->setDate($_GET['date']);
                        $metier->setDuree($_GET['duree']);
                        $metier->setTitre($_GET['titre']);
                        $metier->setDescription($_GET['episode']);

                        $metier->save();


                    } else if ($_GET["type"] == "serie") {
                        $metier = new SerieMetier();
                        SerieMetier::initPDO();
                        $trucs = SerieMetier::getAll();
                        $metier = new SerieMetier();

                        $metier->setSerieId         ($_GET['id']);
                        $metier->setSerieNom        ($_GET['nom']);
                        $metier->setSerieDescription($_GET['description']);
                        $metier->setSerieNbSaison   ($_GET['nbSaison']);

                        $metier->save();

                    } else if ($_GET["type"] == "saison") {
                        SaisonMetier::initPDO();
                        $trucs = SaisonMetier::getAll();
                        $metier = new SaisonMetier();

                        $metier->setIdSaison   ($_GET['id']);
                        $metier->setIdSerie    ($_GET['idSerie']);
                        $metier->setDescription($_GET['description']);
                        $metier->setDate       ($_GET['date']);
                        $metier->setTitre      ($_GET['titre']);
                        $metier->setNbEpisodes ($_GET['nbEpisodes']);

                        $metier->save();
                    }

                    header("location: ./Modification.php?type=".$_GET["type"]);
                }

                if ($_GET["type"] == "episode") {
                    EpisodeMetier::initPDO();
                    $trucs = EpisodeMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id episode</th><th>id saison</th><th>id serie</th><th>date</th><th>duree</th><th>titre</th><th>episode</th></tr>";
                    foreach ($trucs as $truc) {
                        if (isset($_GET["id"]) && $_GET["id"] == $truc->getIdEpisode() && $truc->getIdSerie() == $_GET["idSerie"] && $truc->getIdSaison() == $_GET["idSaison"]) {
                            echo "<form method='get' class='form-check'>";
                            echo "<input hidden name='modifier'/>";
                            echo "<input hidden name='type' value='episode'/>";
                            echo "<input hidden name='id' value='".$truc->getIdEpisode()."'/>";
                            echo "<input hidden name='idSaison' value='".$truc->getIdSaison()."'/>";
                            echo "<input hidden name='idSerie' value='".$truc->getIdSerie()."'/>";
                            echo "<tr>";
                            echo "<td>".$truc->getIdEpisode()."</td>";
                            echo "<td>".$truc->getIdSaison()."</td>";
                            echo "<td>".$truc->getIdSerie()."</td>";

                            echo "<td><input name='date' type='text' value='".$truc->getDate()."'></input></td>";
                            echo "<td><input name='duree' type='text' value='".$truc->getDuree()."'></input></td>";
                            echo "<td><input name='titre' type='text' value='".$truc->getTitre()."'></input></td>";
                            echo "<td><input name='episode' type='text' value='".$truc->getDescription()."'></input></td>";

                            echo "<td><input type='submit' value='Valider'></input></td>";
                            echo "</tr>";
                            echo "</form>";
                        }
                        else{
                            echo "<tr>";
                            $id = $truc->getIdEpisode();
                            $idSerie = $truc->getIdSerie();
                            $idSaison = $truc->getIdSaison();
                            echo $truc;
                            echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Modifier\"><input type='hidden' value='$id' name='id'><input type='hidden' value='$idSerie' name='idSerie'><input type='hidden' value='$idSaison' name='idSaison'><input type='hidden' value='episode' name='type'></form></td>";
                            echo "</tr>";
                        }
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "serie") {
                    SerieMetier::initPDO();
                    $trucs = SerieMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id</th><th>nom</th><th>description</th><th>nb saison</th></tr>";
                    foreach ($trucs as $truc) {
                        if (isset($_GET["id"]) && $truc->getSerieId() == $_GET["id"]) {
                            echo "<form method='get' class='form-check'>";
                            echo "<input hidden name='modifier'/>";
                            echo "<input hidden name='type' value='serie'/>";
                            echo "<input hidden name='id' value='".$truc->getSerieId()."'/>";
                            echo "<tr>";
                            echo "<td>".$truc->getSerieId()."</td>";

                            echo "<td><input name='nom' type='text' value='".$truc->getSerieNom()."'></input></td>";
                            echo "<td><input name='description' type='text' value='".$truc->getSerieDescription()."'></input></td>";
                            echo "<td><input name='nbSaison' type='text' value='".$truc->getSerieNbSaison()."'></input></td>";

                            echo "<td><input type='submit' value='Valider'></input></td>";
                            echo "</tr>";
                            echo "</form>";
                        }
                        else {
                            echo "<tr>";
                            $id = $truc->getSerieId();
                            echo $truc;
                            echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Modifier\"><input type='hidden' value='$id' name='id'><input type='hidden' value='serie' name='type'></form></td>";
                            echo "</tr>";
                        }
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "saison") {
                    SaisonMetier::initPDO();
                    $trucs = SaisonMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id saison</th><th>id serie</th><th>decription</th><th>date</th><th>titre</th><th>nb episode</th></tr>";
                    foreach ($trucs as $truc) {
                        if( isset($_GET["id"]) && $truc->getIdSaison() == $_GET["id"] && $truc->getIdSerie() == $_GET["idSerie"] ){
                            echo "<form method='get' class='form-check'>";
                            echo "<input hidden name='modifier'/>";
                            echo "<input hidden name='type' value='saison'/>";
                            echo "<input hidden name='id' value='".$truc->getIdSaison()."'/>";
                            echo "<input hidden name='idSerie' value='".$truc->getIdSerie()."'/>";
                            echo "<tr>";
                            echo "<td>".$truc->getIdSaison()."</td>";
                            echo "<td>".$truc->getIdSerie()."</td>";
                            echo "<td><input name='description' type='text' value='".$truc->getDescription()."'></input></td>";
                            echo "<td><input name='date' type='date' value='".$truc->getDate()."'></input></td>";
                            echo "<td><input name='titre' type='text' value='".$truc->getTitre()."'></input></td>";
                            echo "<td><input name='nbEpisodes' type='text' value='".$truc->getNbEpisodes()."'></input></td>";
                            echo "<td><input type='submit' value='Valider'></input></td>";
                            echo "</tr>";
                            echo "</form>";
                        } else {
                            echo "<tr>";
                            echo $truc;
                            $id = $truc->getIdSaison();
                            $idSerie = $truc->getIdSerie();
                            echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Modifier\"><input type='hidden' value='$id' name='id'><input type='hidden' value='saison' name='type'><input type='hidden' value='$idSerie' name='idSerie'></form></td>";
                            echo "</tr>";
                        }
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "personne") {
                    PersonneMetier::initPDO();
                    $trucs = PersonneMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id</th><th>nom</th><th>prenom</th></tr>";
                    foreach ($trucs as $truc) {
                        if (isset($_GET["id"] ) && $truc->getId() == $_GET["id"]) {
                            echo "<form method='get' class='form-check'>";
                            echo "<input hidden name='modifier'/>";
                            echo "<input hidden name='type' value='personne'/>";
                            echo "<input hidden name='id' value='".$truc->getId()."'/>";
                            echo "<tr>";
                            echo "<td>".$truc->getId()."</td>";

                            echo "<td><input name='nom' type='text' value='".$truc->getNom()."'></input></td>";
                            echo "<td><input name='prenom' type='text' value='".$truc->getPrenom()."'></input></td>";

                            echo "<td><input type='submit' value='Valider'></input></td>";
                            echo "</tr>";
                            echo "</form>";
                        }
                        else {
                            echo "<tr>";
                            $id = $truc->getId();
                            echo $truc;
                            echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Modifier\"><input type='hidden' value='$id' name='id'><input type='hidden' value='personne' name='type'></form></td>";
                            echo "</tr>";
                        }
                    }
                    echo "</table>";
                } else {
                    echo "<h3>Type invalide. Selectionnez une table sur la gauche de la page.</h3>";
                }
            } else {
                echo "<h3>Selectionnez une table sur la gauche de la page.</h3>";
            }
            echo "</div>";
            ?>
        </div>
    </div>
<?php
echo getFooter();
?>