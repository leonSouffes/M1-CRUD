# InfoWeb TP-CRUD

- Année : **L3 Info**
- Matière: *InfoWeb*
- TP : *CRUD* (Base de données sur les Séries TV)

## Auteur(s)

|Nom|Prénom|
|--|--|
*Cousin* | *Gabriel*|
*Maillard* | *Alban*|
*Mercou* | *Allan*|
*Souffes* | *Léon*|

Pour la répartition du travail, voir les Co-Author sur les différents commits.
