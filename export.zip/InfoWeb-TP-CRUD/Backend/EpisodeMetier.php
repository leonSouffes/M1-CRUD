<?php

$_ENV['host'] = "localhost";
$_ENV['user'] = "ma173017";
$_ENV['db'] = "ma173017";
$_ENV['passwd'] = "20173017";


class EpisodeMetier {

    /**
     * gestion statique des accès SGBD
     * @var PDO
     */
    private static $_pdo;

    /**
     * gestion statique de la requête préparée de selection
     * @var PDOStatement
     */
    private static $_pdos_select;

    /**
     * gestion statique de la requête préparée de mise à jour
     *  @var PDOStatement
     */
    private static $_pdos_update;

    /**
     * gestion statique de la requête préparée de d'insertion
     * @var PDOStatement
     */
    private static $_pdos_insert;

    /**
     * gestion statique de la requête préparée de suppression
     * @var PDOStatement
     */
    private static $_pdos_delete;

    /**
     * PreparedStatement associé à un SELECT, calcule le nombre de livres de la table
     * @var PDOStatement;
     */
    private static $_pdos_count;

    /**
     * PreparedStatement associé à un SELECT, récupère tous les livres
     * @var PDOStatement;
     */
    private static $_pdos_selectAll;



    /**
     * Initialisation de la connexion et mémorisation de l'instance PDO dans LivreMetier::$_pdo
     */
    public static function initPDO() {
        self::$_pdo = new PDO("mysql:host=".$_ENV['host'].";dbname=".$_ENV['db'],$_ENV['user'],$_ENV['passwd']);
        // pour récupérer aussi les exceptions provenant de PDOStatement
        self::$_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    /**
     * préparation de la requête SELECT * FROM livre
     * instantiation de self::$_pdos_selectAll
     */
    public static function initPDOS_selectAll() {
        self::$_pdos_selectAll = self::$_pdo->prepare('SELECT * FROM episode');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_select
     */
    public static function initPDOS_select() {
        self::$_pdos_select = self::$_pdo->prepare('SELECT * FROM episode WHERE id= :idEpisode AND id_saison=:idSaison AND id_serie=:idSerie');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_update
     */
    public static function initPDOS_update() {
        self::$_pdos_update =  self::$_pdo->prepare('UPDATE episode SET date=:date, duree=:duree, titre=:titre, description=:description WHERE id= :idEpisode AND id_saison=:idSaison AND id_serie=:idSerie');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_insert
     */
    public static function initPDOS_insert() {
        self::$_pdos_insert = self::$_pdo->prepare('INSERT INTO episode VALUES(:duree,:date,:titre,:description)');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_delete
     */
    public static function initPDOS_delete() {
        self::$_pdos_delete = self::$_pdo->prepare('DELETE FROM episode WHERE id=:idEpisode AND id_saison=:idSaison AND id_serie=:idSerie');
    }

    /**
     * préparation de la requête SELECT COUNT(*) FROM livre
     * instantiation de self::$_pdos_count
     */
    public static function initPDOS_count() {
        if (!isset(self::$_pdo))
            self::initPDO();
        self::$_pdos_count = self::$_pdo->prepare('SELECT COUNT(*) FROM episode');
    }

    /**
     * @var int
     */
    protected $id;

    /**
     * numéro de la saison (identifiant dans la table Livre)
     * @var int
     */
    protected $id_saison;

    /**
     * numero saison
     * @var int
     */
    protected $id_serie;

    /**
     * @var DateTime
     */
    protected $date;


    protected $duree;

    /**
     * @var string
     */
    protected $titre;

    /**
     * dépot légal de la saison
     *   @var string
     */
    protected $description;

    /**
     * attribut interne pour différencier les nouveaux objets des objets créés côté applicatif de ceux issus du SGBD
     * @var bool
     */
    private $nouveau = FALSE;

    /**
     * @return int
     */
    public function getIdEpisode(): int
    {
        return $this->id;
    }

    /**
     * @param int $id_episode
     */
    public function setIdEpisode(int $id_episode): void
    {
        $this->id = $id_episode;
    }

    /**
     * @return int
     */
    public function getIdSaison(): int
    {
        return $this->id_saison;
    }

    /**
     * @param int $id_saison
     */
    public function setIdSaison(int $id_saison): void
    {
        $this->id_saison = $id_saison;
    }

    /**
     * @return int
     */
    public function getIdSerie(): int
    {
        return $this->id_serie;
    }


    /**
     * @param int $id_serie
     */
    public function setIdSerie(int $id_serie): void
    {
        $this->id_serie = $id_serie;
    }

    /**
     * @return DateTime
     */
    public function getDate(): String
    {
        return $this->date;
    }

    /**
     * @param DateTime $date
     */
    public function setDate(String $date): void
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getDuree()
    {
        return $this->duree;
    }

    /**
     * @param mixed $duree
     */
    public function setDuree($duree): void
    {
        $this->duree = $duree;
    }

    /**
     * @return string
     */
    public function getTitre(): string
    {
        return $this->titre;
    }

    /**
     * @param string $titre
     */
    public function setTitre(string $titre): void
    {
        $this->titre = $titre;
    }

    /**
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description): void
    {
        $this->description = $description;
    }


    /**
     * @return un tableau de tous les LivreMetier
     */
    public static function getAll(): array {
        try {
            if (!isset(self::$_pdo))
                self::initPDO();
            if (!isset(self::$_pdos_selectAll))
                self::initPDOS_selectAll();
            self::$_pdos_selectAll->execute();
            // résultat du fetch dans une instance de LivreMetier
            $lesEpisodes = self::$_pdos_selectAll->fetchAll(PDO::FETCH_CLASS,'EpisodeMetier');
            return $lesEpisodes;
        }
        catch (PDOException $e) {
            print($e);
        }
    }


    /**
     * initialisation d'un objet métier à partir d'un enregistrement de livre
     * @param $liv_num un identifiant de livre
     * @return l'instance de LivreMetier associée à $liv_num
     */
    public static function initEpisodeMetier($idEpisode,$idSerie,$idSaison) : EpisodeMetier {
        try {
            if (!isset(self::$_pdo))
                self::initPDO();
            if (!isset(self::$_pdos_select))
                self::initPDOS_select();
            self::$_pdos_select->bindValue(':idEpisode',$idEpisode);
            self::$_pdos_select->bindValue(':idSerie',$idSerie);
            self::$_pdos_select->bindValue(':idSaison',$idSaison);
            self::$_pdos_select->execute();
            // résultat du fetch dans une instance de LivreMetier
            $lm = self::$_pdos_select->fetchObject('EpisodeMetiers');
            if (isset($lm) && ! empty($lm))
                $lm->setNouveau(FALSE);
            if (empty($lm))
                throw new Exception("L'episode $idEpisode de la serie $idSerie et la saison $idSaison est inexistant dans la table Saison.\n");
            return $lm;
        }
        catch (PDOException $e) {
            print($e);
        }
    }

    /**
     * sauvegarde d'un objet métier
     * soit on insère un nouvel objet
     * soit on le met à jour
     */
    public function save() : void {
        if (!isset(self::$_pdo))
            self::initPDO();
        if ($this->nouveau) {
            if (!isset(self::$_pdos_insert)) {
                self::initPDOS_insert();
            }
            self::$_pdos_insert->bindParam(':idEpisode', $this->id);
            self::$_pdos_insert->bindParam(':idSerie', $this->id_serie);
            self::$_pdos_insert->bindParam(':idSaison', $this->id_saison);
            self::$_pdos_insert->bindParam(':date', $this->date);
            self::$_pdos_insert->bindParam(':duree', $this->duree);
            self::$_pdos_insert->bindParam(':titre', $this->titre);
            self::$_pdos_insert->bindParam(':description', $this->description);
            self::$_pdos_insert->execute();
            $this->setNouveau(FALSE);
        }
        else {
            if (!isset(self::$_pdos_update))
                self::initPDOS_update();
            self::$_pdos_update->bindParam(':idEpisode', $this->id);
            self::$_pdos_update->bindParam(':idSerie', $this->id_serie);
            self::$_pdos_update->bindParam(':idSaison', $this->id_saison);
            self::$_pdos_update->bindParam(':date', $this->date);
            self::$_pdos_update->bindParam(':duree', $this->duree);
            self::$_pdos_update->bindParam(':titre', $this->titre);
            self::$_pdos_update->bindParam(':description', $this->description);
            self::$_pdos_update->execute();
        }
    }

    /**
     * suppression d'un objet métier
     */
    public function delete() :void {
        if (!isset(self::$_pdo))
            self::initPDO();
        if (!$this->nouveau) {
            if (!isset(self::$_pdos_delete)) {
                self::initPDOS_delete();
            }
            self::$_pdos_delete->bindParam(':idEpisode', $this->id);
            self::$_pdos_delete->bindParam(':idSaison', $this->id_saison);
            self::$_pdos_delete->bindParam(':idSerie', $this->id_serie);
            self::$_pdos_delete->execute();
        }
        $this->setNouveau(TRUE);
    }

    /**
     * nombre d'objets metier disponible dans la table
     */
    public static function getNbEpisode() : int {
        if (!isset(self::$_pdos_count)) {
            self::initPDOS_count();
        }
        self::$_pdos_count->execute();
        $resu = self::$_pdos_count->fetch();
        return $resu[0];
    }



    /**
     * affichage élémentaire
     */
    public function __toString() : string {
        //$ch = "<table border='1'><tr><th>id episode</th><th>id saison</th><th>id serie</th><th>date</th><th>duree</th><th>titre</th><th>episode</th></tr><tr>";
        $ch="";
        $ch.= "<td>".$this->id."</td>";
        $ch.= "<td>".$this->id_saison."</td>";
        $ch.= "<td>".$this->id_serie."</td>";
        $ch.= "<td>".$this->date."</td>";
        $ch.= "<td>".$this->duree."</td>";
        $ch.= "<td>".$this->titre."</td>";
        $ch.= "<td>".$this->description."</td>";
        //$ch.= "</tr></table>";
        return $ch;
    }


    private function setNouveau(bool $TRUE)
    {
        $this->nouveau = $TRUE;
    }

}


