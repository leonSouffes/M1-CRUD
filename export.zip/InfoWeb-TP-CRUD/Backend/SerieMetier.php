<?php

$_ENV['host'] = "localhost";
$_ENV['user'] = "ma173017";
$_ENV['db'] = "ma173017";
$_ENV['passwd'] = "20173017";


class SerieMetier {

    /**
     * gestion statique des accès SGBD
     * @var PDO
     */
    private static $_pdo;

    /**
     * gestion statique de la requête préparée de selection
     * @var PDOStatement
     */
    private static $_pdos_select;

    /**
     * gestion statique de la requête préparée de mise à jour
     *  @var PDOStatement
     */
    private static $_pdos_update;

    /**
     * gestion statique de la requête préparée de d'insertion
     * @var PDOStatement
     */
    private static $_pdos_insert;

    /**
     * gestion statique de la requête préparée de suppression
     * @var PDOStatement
     */
    private static $_pdos_delete;

    /**
     * PreparedStatement associé à un SELECT, calcule le nombre de livres de la table
     * @var PDOStatement;
     */
    private static $_pdos_count;

    /**
     * PreparedStatement associé à un SELECT, récupère tous les livres
     * @var PDOStatement;
     */
    private static $_pdos_selectAll;



    /**
     * Initialisation de la connexion et mémorisation de l'instance PDO dans LivreMetier::$_pdo
     */
    public static function initPDO() {
        self::$_pdo = new PDO("mysql:host=".$_ENV['host'].";dbname=".$_ENV['db'],$_ENV['user'],$_ENV['passwd']);
        // pour récupérer aussi les exceptions provenant de PDOStatement
        self::$_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    /**
     * préparation de la requête SELECT * FROM livre
     * instantiation de self::$_pdos_selectAll
     */
    public static function initPDOS_selectAll() {
        self::$_pdos_selectAll = self::$_pdo->prepare('SELECT * FROM serie');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_select
     */
    public static function initPDOS_select() {
        self::$_pdos_select = self::$_pdo->prepare('SELECT * FROM serie WHERE id= :id');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_update
     */
    public static function initPDOS_update() {
        self::$_pdos_update =  self::$_pdo->prepare('UPDATE serie SET nom=:nom, description=:description,nb_saison=:nbSaison WHERE id=:id');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_insert
     */
    public static function initPDOS_insert() {
        self::$_pdos_insert = self::$_pdo->prepare('INSERT INTO serie VALUES(:nom,:description,:nb_saison)');
    }

    /**
     * méthode statique instanciant LivreMetier::$_pdo_delete
     */
    public static function initPDOS_delete() {
        self::$_pdos_delete = self::$_pdo->prepare('DELETE FROM serie WHERE id=:id');
    }

    /**
     * préparation de la requête SELECT COUNT(*) FROM livre
     * instantiation de self::$_pdos_count
     */
    public static function initPDOS_count() {
        if (!isset(self::$_pdo))
            self::initPDO();
        self::$_pdos_count = self::$_pdo->prepare('SELECT COUNT(*) FROM serie');
    }


    /**
     * numéro du livre (identifiant dans la table Livre)
     * @var int
     */
    protected $id;

    /**
     * titre du livre
     * @var string
     */
    protected $nom;

    /**
     * dépot légal du livre
     *   @var string
     */
    protected $description;

    protected $nb_saison;

    /**
     * attribut interne pour différencier les nouveaux objets des objets créés côté applicatif de ceux issus du SGBD
     * @var bool
     */
    private $nouveau = FALSE;

    /**
     * @return $this->liv_num
     */
    public function getSerieId() : int {
        return $this->id;
    }

    /**
     * @param $liv_num
     */
    public function setSerieId($id): void {
        $this->id=$id;
    }

    /**
     * @return $this->nom
     */
    public function getSerieNom() : string {
        return $this->nom;
    }

    /**
     * @param $liv_titre
     */
    public function setSerieNom($nom): void {
        $this->nom=$nom;
    }

    /**
     * @return $this->liv_depotlegal
     */
    public function getSerieDescription() : string {
        return $this->description;
    }

    /**
     * @param $liv_depotlegal
     */
    public function setSerieDescription($description): void {
        $this->description=$description;
    }

    /**
     * @return $this->nouveau
     */
    public function getSerieNbSaison() : bool {
        return $this->nb_saison;
    }

    /**
     * @param $nouveau
     */
    public function setSerieNbSaison($nbSaison): void {
        $this->nb_saison=$nbSaison;
    }

    /**
     * @return un tableau de tous les LivreMetier
     */
    public static function getAll(): array {
        try {
            if (!isset(self::$_pdo))
                self::initPDO();
            if (!isset(self::$_pdos_selectAll))
                self::initPDOS_selectAll();
            self::$_pdos_selectAll->execute();
            // résultat du fetch dans une instance de LivreMetier
            $lesSerie = self::$_pdos_selectAll->fetchAll(PDO::FETCH_CLASS,'SerieMetier');
            return $lesSerie;
        }
        catch (PDOException $e) {
            print($e);
        }
    }


    /**
     * initialisation d'un objet métier à partir d'un enregistrement de livre
     * @param $liv_num un identifiant de livre
     * @return l'instance de LivreMetier associée à $liv_num
     */
    public static function initSerieMetier($serie_id) : SerieMetier {
        try {
            if (!isset(self::$_pdo))
                self::initPDO();
            if (!isset(self::$_pdos_select))
                self::initPDOS_select();
            self::$_pdos_select->bindValue(':id',$serie_id);
            self::$_pdos_select->execute();
            // résultat du fetch dans une instance de LivreMetier
            $lm = self::$_pdos_select->fetchObject('SerieMetier');
            if (isset($lm) && ! empty($lm))
                $lm->setNouveau(FALSE);
            if (empty($lm))
                throw new Exception("Serie $serie_id inexistant dans la table Serie.\n");
            return $lm;
        }
        catch (PDOException $e) {
            print($e);
        }
    }

    /**
     * sauvegarde d'un objet métier
     * soit on insère un nouvel objet
     * soit on le met à jour
     */
    public function save() : void {
        if (!isset(self::$_pdo))
            self::initPDO();
        if ($this->nouveau) {
            if (!isset(self::$_pdos_insert)) {
                self::initPDOS_insert();
            }
            self::$_pdos_insert->bindParam(':id', $this->id);
            self::$_pdos_insert->bindParam(':nom', $this->nom);
            self::$_pdos_insert->bindParam(':desciption', $this->description);
            self::$_pdos_insert->bindParam(':nbSaison', $this->nb_saison);
            self::$_pdos_insert->execute();
            $this->setNouveau(FALSE);
        }
        else {
            if (!isset(self::$_pdos_update))
                self::initPDOS_update();
            self::$_pdos_update->bindParam(':id', $this->id);
            self::$_pdos_update->bindParam(':nom', $this->nom);
            self::$_pdos_update->bindParam(':description', $this->description);
            self::$_pdos_update->bindParam(':nbSaison', $this->nb_saison);
            self::$_pdos_update->execute();
        }
    }

    /**
     * suppression d'un objet métier
     */
    public function delete() :void {
        if (!isset(self::$_pdo))
            self::initPDO();
        if (!$this->nouveau) {
            if (!isset(self::$_pdos_delete)) {
                self::initPDOS_delete();
            }
            self::$_pdos_delete->bindParam(':id', $this->id);
            self::$_pdos_delete->execute();
        }
        $this->setNouveau(TRUE);
    }

    /**
     * nombre d'objets metier disponible dans la table
     */
    public static function getNbSerie() : int {
        if (!isset(self::$_pdos_count)) {
            self::initPDOS_count();
        }
        self::$_pdos_count->execute();
        $resu = self::$_pdos_count->fetch();
        return $resu[0];
    }



    /**
     * affichage élémentaire
     */
    public function __toString() : string {
        //$ch = "<table border='1'><tr><th>id</th><th>nom</th><th>description</th><th>nb saison</th></tr><tr>";
        $ch="";
        $ch.= "<td>".$this->id."</td>";
        $ch.= "<td>".$this->nom."</td>";
        $ch.= "<td>".$this->description."</td>";
        $ch.= "<td>".$this->nb_saison."</td>";
        //$ch.= "</tr></table>";
        return $ch;
    }

    private function setNouveau(bool $TRUE)
    {
        $this->nouveau = $TRUE;
    }
}


