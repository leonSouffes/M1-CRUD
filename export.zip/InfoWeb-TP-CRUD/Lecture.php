<?php
include_once("Utilities.php");
include_once("Backend/EpisodeMetier.php");
include_once("Backend/PersonneMetier.php");
include_once("Backend/SaisonMetier.php");
include_once("Backend/SerieMetier.php");

echo getHeader("Lecture");
?>

    <div class="container-fluid">
        <div class="row">
            <?php
            echo getSideBar();
            ?>

            <?php
            echo "<div class=\"col-10 mt-2\">";
            if (isset($_GET["type"])) {
                if ($_GET["type"] == "episode") {
                    EpisodeMetier::initPDO();
                    $trucs = EpisodeMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id episode</th><th>id saison</th><th>id serie</th><th>date</th><th>duree</th><th>titre</th><th>episode</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        echo "</tr>";
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "serie") {
                    SerieMetier::initPDO();
                    $trucs = SerieMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id</th><th>nom</th><th>description</th><th>nb saison</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        echo "</tr>";
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "saison") {
                    SaisonMetier::initPDO();
                    $trucs = SaisonMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id saison</th><th>id serie</th><th>decription</th><th>date</th><th>titre</th><th>nb episode</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        echo "</tr>";
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "personne") {
                    PersonneMetier::initPDO();
                    $trucs = PersonneMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id</th><th>nom</th><th>prenom</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<h3>Type invalide. Selectionnez une table sur la gauche de la page.</h3>";
                }
            } else {
                echo "<h3>Selectionnez une table sur la gauche de la page.</h3>";
            }
            echo "</div>";
            ?>
        </div>
    </div>

<?php
echo getFooter();
?>