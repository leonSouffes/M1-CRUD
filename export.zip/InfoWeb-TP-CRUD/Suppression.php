<?php
include_once("Utilities.php");
include_once("Backend/EpisodeMetier.php");
include_once("Backend/PersonneMetier.php");
include_once("Backend/SaisonMetier.php");
include_once("Backend/SerieMetier.php");

echo getHeader("Suppression");
?>

    <div class="container-fluid">
        <div class="row">
            <?php
            echo getSideBar();
            ?>

            <?php
            echo "<div class=\"col-10 mt-2\">";
            if (isset($_GET["type"])) {
                if (isset($_GET["id"])) {
                    // on va supprimer cet id !!!
                    if ($_GET["type"] == "personne") {
                        $metier = new PersonneMetier();
                        $metier->setId($_GET["id"]);
                        $metier->delete();
                    } else if ($_GET["type"] == "episode") {
                        $metier = new EpisodeMetier();
                        $metier->setIdEpisode($_GET["id"]);
                        $metier->setIdSerie($_GET["idSerie"]);
                        $metier->setIdSaison($_GET["idSaison"]);
                        $metier->delete();
                    } else if ($_GET["type"] == "serie") {
                        $metier = new SerieMetier();
                        $metier->setSerieId($_GET["id"]);
                        $metier->delete();
                    } else if ($_GET["type"] == "saison") {
                        $metier = new SaisonMetier();
                        $metier->setIdSaison($_GET["id"]);
                        $metier->setIdSerie($_GET["idSerie"]);
                        $metier->delete();
                    }
                }

                if ($_GET["type"] == "episode") {
                    EpisodeMetier::initPDO();
                    $trucs = EpisodeMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id episode</th><th>id saison</th><th>id serie</th><th>date</th><th>duree</th><th>titre</th><th>episode</th><th>supprimer</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        $id = $truc->getIdEpisode();
                        $idSerie = $truc->getIdSerie();
                        $idSaison = $truc->getIdSaison();
                        echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Supprimer\"><input type='hidden' value='$id' name='id'><input type='hidden' value='episode' name='type'><input type='hidden' value='$idSaison' name='idSaison'><input type='hidden' value='$idSerie' name='idSerie'></form></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "serie") {
                    SerieMetier::initPDO();
                    $trucs = SerieMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id</th><th>nom</th><th>description</th><th>nb saison</th><th>supprimer</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        $id = $truc->getSerieId();
                        echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Supprimer\"><input type='hidden' value='$id' name='id'><input type='hidden' value='serie' name='type'></form></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "saison") {
                    SaisonMetier::initPDO();
                    $trucs = SaisonMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id saison</th><th>id serie</th><th>decription</th><th>date</th><th>titre</th><th>nb episode</th><th>supprimer</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        $id = $truc->getIdSaison();
                        $idSerie = $truc->getIdSerie();
                        echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Supprimer\"><input type='hidden' value='$id' name='id'><input type='hidden' value='saison' name='type'><input type='hidden' value='$idSerie' name='idSerie'></form></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else if ($_GET["type"] == "personne") {
                    PersonneMetier::initPDO();
                    $trucs = PersonneMetier::getAll();
                    echo "<table class='table table-bordered table-responsive table-striped' border='1'><tr><th>id</th><th>nom</th><th>prenom</th><th>supprimer</th></tr>";
                    foreach ($trucs as $truc) {
                        echo "<tr>";
                        echo $truc;
                        $id = $truc->getId();
                        echo "<td><form method='get' class='form-check'><input type=\"submit\" value=\"Supprimer\"><input type='hidden' value='$id' name='id'><input type='hidden' value='personne' name='type'></form></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<h3>Type invalide. Selectionnez une table sur la gauche de la page.</h3>";
                }
            } else {
                echo "<h3>Selectionnez une table sur la gauche de la page.</h3>";
            }
            echo "</div>";
            ?>
        </div>
    </div>

<?php
echo getFooter();
?>