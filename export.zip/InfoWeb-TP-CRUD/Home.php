<?php
include_once("Utilities.php");
echo getHeader();
?>

<div class="container-fluid">
    <div class="row">

    </div>
</div>

<?php
echo getFooter();
?>